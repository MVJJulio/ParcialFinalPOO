/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.parcialfinal;

import java.net.Socket;

/**
 *
 * @author abele
 */
public class ParcialFinal {

    public static void main(String[] args) {
        
        
    }
}

